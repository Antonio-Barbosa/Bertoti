public class Divisao implements Calculo{
    public void calculoOperacao() {
        System.out.println("Divisao!");
    }
}

