public class Multiplicacao implements Calculo {

    public void calculoOperacao () {
        System.out.println("Multiplicação!");
    }
    
}
