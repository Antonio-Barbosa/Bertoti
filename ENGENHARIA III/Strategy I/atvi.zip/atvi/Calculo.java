public interface Calculo {
    
    public void calculoOperacao();

}
