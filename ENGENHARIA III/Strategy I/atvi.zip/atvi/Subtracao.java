public class Subtracao implements Calculo{

    public void calculoOperacao() {
        System.out.println("Subtração!!");
    }
    
}
