public class Adicao implements Calculo {
    public void calculoOperacao() {
        System.out.println("Adição!");
    }
    
}
