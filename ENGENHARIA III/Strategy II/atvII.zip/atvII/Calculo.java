public interface Calculo {
    
    public void calculoOperacao(int x, int y);

}
