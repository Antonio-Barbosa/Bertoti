public class Adicao implements Calculo {
    public void calculoOperacao(int x, int y) {
        System.out.println(x + y);
    }
    
}
